function testfunctie1() {
    document.getElementById("Extra").innerHTML = "Barcelona is de grootste stad van Catalonie en op Madrid na de grootste stad van Spanje. Het is de stad voor een stedentrip in het voor- en najaar. Je kunt er namelijk al snel genieten van een heerlijk zonnetje op een van de vele gezellig pleinen. In de mediterrane stad is ontzettend veel te beleven. Je kunt dagenlang vullen met Spaanse tapas, terrasjes, zon en strand.";
}
function testfunctie2() {
    document.getElementById("Extra").innerHTML = "Athene is de hoofdstad, grootste stad van Griekenland en een van de grootste steden van Europa. In de streek Attika wonen 3.812.330 mensen, waarvan er 3.192.606 in de metropool Athene. Dus niet alleen de gemeente Athene, maar de grote stad en het stedelijke gebied hieromheen. In de gemeente Athene wonen 664.046 mensen. Athene is het centrum van alle centra ter wereld. Het is de stad van de Olympische Spelen.";
}
function testfunctie3() {
    document.getElementById("Extra").innerHTML = "Tokyo is de moderne hoofdstad van Japan. Het is een metropool waar miljoenen mensen samen leven, werken en consumeren. Hierdoor is er een enorme economie ontstaan, zeker als je de gehele metropool Tokyo bekijkt inclusief alle voorsteden. Het totale aantal inwoners van het grootstedelijk gebied overstijgt tegenwoordig de veertig miljoen, waarmee Tokyo een van de grootste wereldsteden op aarde is.";
}
function testfunctie4() {
    document.getElementById("Extra").innerHTML = "Johannesburg, of Joburg, ligt in de provincie Gauteng, dat gouden plek betekent. De bedrijvige commerciele stad staat bol van levenslust en heeft zijn bestaan te danken aan de goudkoorts. Toen er in 1886 goud werd gevonden, groeide de stad binnen enkele jaren uit tot de grootste van Zuid-Afrika. Inmiddels is Johannesburg het financiele centrum van Zuid-Afrika, met hoge wolkenkrabbers en groene buitenwijken.";
}
function testfunctie5() {
    document.getElementById("Extra").innerHTML = "Texas is op Alaska na de grootste staat van Amerika. De staat is op vele vlakken divers te beschouwen. Zo is het klimaat van Texas zeer uiteenlopend. In het zuidoosten van de staat zijn moerassen te vinden, in het uiterste zuiden en zuidwesten ligt het woestijn, in het midden de uitgestrekte weiden en in het noordwesten een voorzichtig begin van de impossante Rocky Mountains.";
}